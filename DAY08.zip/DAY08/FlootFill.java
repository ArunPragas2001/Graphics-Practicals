public class BinaryTreeArray {
    String[] tree;
    int size;

    public BinaryTreeArray(int capacity) {
        tree = new String[capacity];
        size = 0;
    }

    public void add(String value) {
        if (size < tree.length) {
            tree[size++] = value;
        } else {
            System.out.println("Tree is full");
        }
    }

    public void printChildren(int index) {
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size) {
            System.out.println("Left child of " + tree[index] + ": " + tree[left]);
        }
        if (right < size) {
            System.out.println("Right child of " + tree[index] + ": " + tree[right]);
        }
    }

    public void printTree() {
        for (int i = 0; i < size; i++) {
            System.out.println("Node at index " + i + ": " + tree[i]);
        }
    }

    public static void main(String[] args) {
        BinaryTreeArray bt = new BinaryTreeArray(10);
        bt.add("A");
        bt.add("B");
        bt.add("C");
        bt.add("D");
        bt.add("E");
        bt.add("F");

        bt.printTree();
        bt.printChildren(0); // Children of A
        bt.printChildren(1); // Children of B
    }
}
