import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class FloodFilling extends JFrame implements MouseListener {

    BufferedImage canvas;
    Color fillColor = Color.RED;
    Graphics2D g;

    public FloodFilling() {
        setTitle("Flood Fill Algorithm");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addMouseListener(this);
        setLocationRelativeTo(null);
        setVisible(true);

        canvas = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);
        g = canvas.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 800, 600);

        // Draw a rectangle as the region to fill
        g.setColor(Color.GREEN);
        g.fillRect(200, 150, 400, 300);
    }

    // Flood Fill (4-connected)
    private void floodFill(int x, int y, Color targetColor, Color fillColor) {
        // Boundary check
        if (x < 0 || y < 0 || x >= canvas.getWidth() || y >= canvas.getHeight()) {
            return;
        }

        Color currentColor = new Color(canvas.getRGB(x, y), true);

        // Base conditions:
        if (!currentColor.equals(targetColor) || currentColor.equals(fillColor)) {
            return;
        }

        // Set new color
        canvas.setRGB(x, y, fillColor.getRGB());

        // Recursive calls (4-connected)
        floodFill(x + 1, y, targetColor, fillColor);
        floodFill(x - 1, y, targetColor, fillColor);
        floodFill(x, y + 1, targetColor, fillColor);
        floodFill(x, y - 1, targetColor, fillColor);
		
		floodFill(x + 1, y+1, targetColor, fillColor);
        floodFill(x - 1, y-1, targetColor, fillColor);
        floodFill(x+1, y - 1, targetColor, fillColor);
        floodFill(x-1, y+1, targetColor, fillColor);
		
		
		
    }

    @Override
    public void paint(Graphics gScreen) {
        gScreen.drawImage(canvas, 0, 0, null);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();

        Color targetColor = new Color(canvas.getRGB(x, y), true);

        if (!targetColor.equals(fillColor)) {
            floodFill(x, y, targetColor, fillColor);
            repaint();
        }
    }

    // Unused MouseListener methods
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    public static void main(String[] args) {
        new FloodFilling();
    }
}
