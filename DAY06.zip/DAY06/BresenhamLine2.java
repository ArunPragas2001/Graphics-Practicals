import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class BresenhamLine2 extends JFrame implements MouseListener {
    Graphics g;
    int x1, y1, x2, y2;

    BresenhamLine2() {
        setTitle("Bresenham Algorithm");
        setSize(800, 600);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addMouseListener(this);
        setLocationRelativeTo(null);
        setVisible(true);
        g = getGraphics();
    }

    public void bresenhamLineAlgo(int x1, int y1, int x2, int y2) 
	{ 
	
		int dx=Math.abs(x2-x1);
		int dy=Math.abs(y2-y1);
		int d0= 2*dy-dx;
	    int x=x1;
		int y=y1;
	     int tempY=y;
		
	    if(x1<x2)
		{
			for(int i=x1; i<x2; i++)
			{
				
				if(d0<0)
				{	
			      
				  tempY+=y;
				  d0+=2*dy;
				  
				}
				else
				{
				  tempY=y;
				  d0+=2*(dy-dx);
				}
				
				
				
				
			}
			
				g.drawLine(x1,y1,x2,y2);
		}
		
		
		
	
		
		
		
		
        //full fill the method
    }

   
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {
        x1 = e.getX();
        y1 = e.getY();
    }
    public void mouseReleased(MouseEvent e) {
        x2 = e.getX();
        y2 = e.getY();
        bresenhamLineAlgo(x1, y1, x2, y2);
    }

    public static void main(String[] args) {
        new BresenhamLine();
    }
}
